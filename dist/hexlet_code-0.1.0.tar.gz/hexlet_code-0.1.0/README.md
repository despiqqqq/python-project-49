### Hexlet tests and linter status:
[![Actions Status](https://github.com/despiqqqq/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/despiqqqq/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/881a0f67e1435d4d8bcf/maintainability)](https://codeclimate.com/github/despiqqqq/python-project-49/maintainability)